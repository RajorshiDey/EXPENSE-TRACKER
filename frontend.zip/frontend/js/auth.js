const API = typeof API_BASE_URL !== "undefined" ? API_BASE_URL : "http://127.0.0.1:3000";

async function checkSession() {
    const page = location.pathname.split("/").pop();

    if (!["index.html", ""].includes(page)) {
        return;
    }

    try {
        const response = await fetch(`${API}/api/auth/profile`, {
            credentials: "include"
        });

        if (response.ok) {
            location.href = "dashboard.html";
        }
    } catch (error) {
        console.log("User is not logged in.");
    }
}

function showMessage(element, message, type = "error") {
    if (!element) return;
    element.textContent = message;
    element.className = `form-message ${type}`;
}

/* LOGIN */
document.getElementById("loginForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();

    const message = document.getElementById("formMessage");
    showMessage(message, "Logging in...", "success");

    try {
        const response = await fetch(`${API}/api/auth/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",
            body: JSON.stringify({
                email: document.getElementById("email").value.trim(),
                password: document.getElementById("password").value
            })
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(data.message || "Login failed");
        }

        location.href = "dashboard.html";
    } catch (error) {
        showMessage(message, error.message);
    }
});

/* REGISTER */
document.getElementById("registerForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();

    const message = document.getElementById("formMessage");
    showMessage(message, "Creating account...", "success");

    try {
        const response = await fetch(`${API}/api/auth/register`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",
            body: JSON.stringify({
                name: document.getElementById("name").value.trim(),
                email: document.getElementById("email").value.trim(),
                password: document.getElementById("password").value
            })
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(data.message || "Registration failed");
        }

        showMessage(message, "Account created. Redirecting to login...", "success");
        setTimeout(() => {
            location.href = "login.html";
        }, 800);
    } catch (error) {
        showMessage(message, error.message);
    }
});

checkSession();