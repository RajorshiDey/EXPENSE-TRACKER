const API = typeof API_BASE_URL !== "undefined" ? API_BASE_URL : "http://127.0.0.1:3000";

let expenses = [];

const $ = (id) => document.getElementById(id);

function money(number) {
    return `₹${Number(number || 0).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })}`;
}

function dateText(value) {
    if (!value) return "";
    const date = new Date(value);
    return isNaN(date.getTime())
        ? String(value)
        : date.toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "short",
              year: "numeric"
          });
}

function formatLocalDate(dateInput = new Date()) {
    const d = new Date(dateInput);
    if (isNaN(d.getTime())) return "";
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

function showMessage(element, text, type = "error") {
    if (!element) return;
    element.textContent = text;
    element.className = `form-message ${type}`;
}

async function api(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
        credentials: "include",
        ...options,
        headers: {
            ...(options.body ? { "Content-Type": "application/json" } : {}),
            ...(options.headers || {})
        }
    });

    if (response.status === 401) {
        location.href = "login.html";
        throw new Error("Authentication required");
    }

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
        throw new Error(data.message || "Request failed");
    }

    return data;
}

async function loadProfile() {
    const data = await api("/api/auth/profile");
    const user = data.user || {};
    const name = user.name || "User";

    $("userName").textContent = name;
    $("welcomeName").textContent = name.split(" ")[0];
    $("avatar").textContent = name.charAt(0).toUpperCase();
}

async function loadExpenses() {
    const data = await api("/api/expenses");
    expenses = data.expenses || [];
    render();
}

function render() {
    const total = expenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);

    const now = new Date();
    const monthTotal = expenses
        .filter((expense) => {
            const date = new Date(expense.date);
            return (
                date.getMonth() === now.getMonth() &&
                date.getFullYear() === now.getFullYear()
            );
        })
        .reduce((sum, expense) => sum + Number(expense.amount || 0), 0);

    $("totalSpent").textContent = money(total);
    $("monthSpent").textContent = money(monthTotal);
    $("transactionCount").textContent = expenses.length;

    renderExpenses();
    renderCategories();
}

function renderExpenses() {
    const list = $("expenseList");

    if (!expenses.length) {
        list.innerHTML = `
            <div class="empty-state">
                No expenses yet. Add your first expense.
            </div>
        `;
        return;
    }

    list.innerHTML = expenses
        .map(
            (expense) => `
            <div class="expense-item">
                <div class="category-dot">
                    ${escapeHtml((expense.category || "?").charAt(0).toUpperCase())}
                </div>

                <div class="expense-info">
                    <strong>${escapeHtml(expense.category)}</strong>
                    <span>
                        ${escapeHtml(expense.description)} · ${dateText(expense.date)}
                    </span>
                </div>

                <div class="expense-amount">
                    ${money(expense.amount)}
                </div>

                <div class="item-actions">
                    <button class="small-btn" onclick="editExpense('${expense._id}')">
                        Edit
                    </button>
                    <button class="small-btn delete" onclick="removeExpense('${expense._id}')">
                        Delete
                    </button>
                </div>
            </div>
        `
        )
        .join("");
}

function renderCategories() {
    const categories = {};

    expenses.forEach((expense) => {
        const category = expense.category;
        categories[category] = (categories[category] || 0) + Number(expense.amount || 0);
    });

    const total = Object.values(categories).reduce((sum, value) => sum + value, 0);
    const list = $("categoryList");

    if (!total) {
        list.innerHTML = `<div class="empty-state">No data yet</div>`;
        return;
    }

    list.innerHTML = Object.entries(categories)
        .sort((a, b) => b[1] - a[1])
        .map(([category, value]) => {
            const percentage = Math.round((value / total) * 100);
            return `
                <div class="cat-row">
                    <div class="cat-top">
                        <span>${escapeHtml(category)}</span>
                        <strong>${money(value)}</strong>
                    </div>
                    <div class="bar">
                        <i style="width: ${percentage}%"></i>
                    </div>
                </div>
            `;
        })
        .join("");
}

function escapeHtml(value) {
    return String(value ?? "").replace(
        /[&<>"']/g,
        (character) =>
            ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[character])
    );
}

function openModal(expense = null) {
    $("expenseModal").classList.remove("hidden");
    $("expenseForm").reset();
    $("expenseId").value = expense?._id || "";

    if (expense) {
        $("modalEyebrow").textContent = "EDIT EXPENSE";
        $("modalTitle").textContent = "Edit expense";
        $("saveExpenseBtn").textContent = "Update expense";

        $("amount").value = expense.amount;
        $("date").value = formatLocalDate(expense.date);
        $("category").value = expense.category;
        $("description").value = expense.description;
    } else {
        $("modalEyebrow").textContent = "NEW EXPENSE";
        $("modalTitle").textContent = "Add an expense";
        $("saveExpenseBtn").textContent = "Save expense";
        $("date").value = formatLocalDate();
    }

    $("expenseMessage").textContent = "";
}

function closeModal() {
    $("expenseModal").classList.add("hidden");
}

window.editExpense = function (id) {
    const expense = expenses.find((item) => item._id === id);
    if (expense) {
        openModal(expense);
    }
};

window.removeExpense = async function (id) {
    const confirmed = confirm("Delete this expense?");
    if (!confirmed) return;

    try {
        await api(`/api/expenses/${id}`, {
            method: "DELETE"
        });
        await loadExpenses();
    } catch (error) {
        alert(error.message);
    }
};

$("addExpenseBtn").addEventListener("click", () => openModal());
$("closeModal").addEventListener("click", closeModal);

$("expenseModal").addEventListener("click", (event) => {
    if (event.target === $("expenseModal")) {
        closeModal();
    }
});

$("refreshBtn").addEventListener("click", loadExpenses);

$("expenseForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const id = $("expenseId").value;
    const expenseData = {
        amount: Number($("amount").value),
        date: $("date").value,
        category: $("category").value,
        description: $("description").value.trim()
    };

    try {
        showMessage($("expenseMessage"), id ? "Updating..." : "Saving...", "success");

        await api(id ? `/api/expenses/${id}` : "/api/expenses", {
            method: id ? "PUT" : "POST",
            body: JSON.stringify(expenseData)
        });

        closeModal();
        await loadExpenses();
    } catch (error) {
        showMessage($("expenseMessage"), error.message);
    }
});

$("logoutBtn").addEventListener("click", async () => {
    try {
        await api("/api/auth/logout", {
            method: "POST"
        });
    } finally {
        location.href = "login.html";
    }
});

(async function () {
    try {
        await loadProfile();
        await loadExpenses();
    } catch (error) {
        console.error("Initialization error:", error);
    }
})();